const KEY="cartera_neuquen_v1";
const defaultState={settings:{interest:20,term:22,commission:4},capital:10000000,clients:[],credits:[],payments:[],cash:[]};
let state=load();
function load(){try{return JSON.parse(localStorage.getItem(KEY))||structuredClone(defaultState)}catch(e){return structuredClone(defaultState)}}
function save(){localStorage.setItem(KEY,JSON.stringify(state));render()}
const money=n=>new Intl.NumberFormat("es-AR",{style:"currency",currency:"ARS",maximumFractionDigits:0}).format(Number(n)||0);
const uid=p=>p+"-"+Date.now().toString(36)+"-"+Math.random().toString(36).slice(2,6);
const today=()=>new Date().toISOString().slice(0,10);
function daysLate(d){return Math.max(0,Math.floor((new Date()-new Date(d+"T23:59:59"))/86400000))}
function client(id){return state.clients.find(x=>x.id===id)}
function creditStatus(c){if(c.status==="finished")return "finished";return c.outstanding<=0?"finished":daysLate(c.dueDate)>0?"overdue":"active"}
function cashBalance(){return state.capital + state.cash.reduce((s,x)=>s+Number(x.entry||0)-Number(x.exit||0),0)}
function totalCollected(){return state.payments.reduce((s,p)=>s+Number(p.amount),0)}
function totalOutstanding(){return state.credits.reduce((s,c)=>s+Math.max(0,Number(c.outstanding)),0)}
function openModal(html){document.getElementById("modalContent").innerHTML=html;document.getElementById("modal").classList.remove("hidden")}
function closeModal(){document.getElementById("modal").classList.add("hidden")}
document.getElementById("closeModal").onclick=closeModal;
document.getElementById("modal").onclick=e=>{if(e.target.id==="modal")closeModal()};

document.querySelectorAll(".nav").forEach(b=>b.onclick=()=>showView(b.dataset.view));
function showView(name){document.querySelectorAll(".view").forEach(v=>v.classList.remove("active"));document.getElementById("view-"+name).classList.add("active");document.querySelectorAll(".nav").forEach(n=>n.classList.toggle("active",n.dataset.view===name));render()}
document.getElementById("menuBtn").onclick=()=>showView("settings");

document.getElementById("addClientBtn").onclick=()=>openModal(`<h2>Nuevo cliente</h2><form id="clientForm" class="form">
<label>Nombre completo<input required name="name"></label><label>Teléfono<input name="phone" inputmode="tel"></label>
<label>Dirección / zona<input name="address"></label><label>Actividad / negocio<input name="business"></label><label>Notas<textarea name="notes"></textarea></label>
<button class="primary">Guardar cliente</button></form>`);
document.addEventListener("submit",e=>{
 if(e.target.id==="clientForm"){e.preventDefault();let f=new FormData(e.target);state.clients.push({id:uid("CLI"),name:f.get("name"),phone:f.get("phone"),address:f.get("address"),business:f.get("business"),notes:f.get("notes"),date:today(),status:"active"});save();closeModal()}
 if(e.target.id==="creditForm"){e.preventDefault();let f=new FormData(e.target), amount=Number(f.get("amount")), interest=Number(f.get("interest")), term=Number(f.get("term"));let total=amount*(1+interest/100), due=new Date(f.get("date"));due.setDate(due.getDate()+term);let c={id:uid("CR"),clientId:f.get("clientId"),date:f.get("date"),amount,interest,interestAmount:total-amount,total,term,daily:total/term,dueDate:due.toISOString().slice(0,10),outstanding:total,status:"active"};state.credits.push(c);state.cash.push({id:uid("CA"),date:today(),type:"disbursement",concept:"Desembolso "+c.id,entry:0,exit:amount});save();closeModal()}
 if(e.target.id==="paymentForm"){e.preventDefault();let f=new FormData(e.target), cr=state.credits.find(x=>x.id===f.get("creditId")), amount=Number(f.get("amount"));if(!cr)return;let comm=amount*state.settings.commission/100;cr.outstanding=Math.max(0,cr.outstanding-amount);cr.status=cr.outstanding<=0?"finished":"active";let p={id:uid("PAY"),creditId:cr.id,clientId:cr.clientId,date:f.get("date"),amount,method:f.get("method"),commission:comm,net:amount-comm};state.payments.push(p);state.cash.push({id:uid("CA"),date:f.get("date"),type:"collection",concept:"Cobro "+p.id,entry:amount-comm,exit:0});state.cash.push({id:uid("CA"),date:f.get("date"),type:"commission",concept:"Comisión 4%",entry:0,exit:comm});save();closeModal()}
 if(e.target.id==="cashForm"){e.preventDefault();let f=new FormData(e.target);state.cash.push({id:uid("CA"),date:f.get("date"),type:f.get("type"),concept:f.get("concept"),entry:Number(f.get("entry")||0),exit:Number(f.get("exit")||0)});save();closeModal()}
 if(e.target.id==="settingsForm"){e.preventDefault();state.settings.interest=Number(document.getElementById("setInterest").value);state.settings.term=Number(document.getElementById("setTerm").value);state.settings.commission=Number(document.getElementById("setCommission").value);save();alert("Configuración guardada")}
});
document.getElementById("addCreditBtn").onclick=()=>openCreditModal();
function openCreditModal(){if(!state.clients.length){alert("Primero crea un cliente.");return}openModal(`<h2>Nuevo crédito</h2><form id="creditForm" class="form">
<label>Cliente<select name="clientId">${state.clients.map(c=>`<option value="${c.id}">${c.name}</option>`).join("")}</select></label>
<label>Monto<input required name="amount" type="number" min="1"></label><label>Interés (%)<input name="interest" type="number" value="${state.settings.interest}" step=".1"></label>
<label>Plazo (días)<input name="term" type="number" value="${state.settings.term}"></label><label>Fecha de desembolso<input name="date" type="date" value="${today()}"></label>
<button class="primary">Crear crédito</button></form>`)}
document.getElementById("addPaymentBtn").onclick=()=>openPaymentModal();
document.getElementById("quickPaymentBtn").onclick=()=>openPaymentModal();
function openPaymentModal(){let active=state.credits.filter(c=>c.outstanding>0);if(!active.length){alert("No hay créditos con saldo pendiente.");return}openModal(`<h2>Registrar pago</h2><form id="paymentForm" class="form">
<label>Crédito<select name="creditId">${active.map(c=>`<option value="${c.id}">${client(c.clientId)?.name||"Cliente"} — saldo ${money(c.outstanding)}</option>`).join("")}</select></label>
<label>Monto pagado<input required name="amount" type="number" min="1"></label><label>Fecha<input name="date" type="date" value="${today()}"></label>
<label>Método<select name="method"><option>Efectivo</option><option>Transferencia</option><option>Otro</option></select></label>
<button class="primary">Guardar pago</button></form>`)}
document.getElementById("addCashBtn").onclick=()=>openModal(`<h2>Movimiento de caja</h2><form id="cashForm" class="form">
<label>Tipo<select name="type"><option>capital</option><option>expense</option><option>other</option></select></label><label>Concepto<input required name="concept"></label>
<label>Entrada<input name="entry" type="number" min="0" value="0"></label><label>Salida<input name="exit" type="number" min="0" value="0"></label>
<label>Fecha<input name="date" type="date" value="${today()}"></label><button class="primary">Guardar movimiento</button></form>`);
document.getElementById("clientSearch").oninput=renderClients;
document.getElementById("creditFilter").onchange=renderCredits;
document.getElementById("settingsForm").onsubmit=null;
document.getElementById("resetBtn").onclick=()=>{if(confirm("¿Borrar los datos actuales y cargar 10 clientes de ejemplo?")){state=seed();save()}};

function seed(){let s=structuredClone(defaultState);s.clients=Array.from({length:10},(_,i)=>({id:`CLI-${String(i+1).padStart(3,"0")}`,name:`Cliente ejemplo ${i+1}`,phone:`299 400-${1000+i}`,address:`Zona ${i+1}`,business:["Almacén","Barbería","Taller","Comercio"][i%4],date:today(),status:"active",notes:"Cliente de prueba"}));return s}
function render(){renderDashboard();renderClients();renderCredits();renderPayments();renderCash();renderReports();document.getElementById("setInterest").value=state.settings.interest;document.getElementById("setTerm").value=state.settings.term;document.getElementById("setCommission").value=state.settings.commission}
function renderDashboard(){let cc=state.credits.filter(c=>c.outstanding>0), ar=cc.filter(c=>daysLate(c.dueDate)>0);document.getElementById("cashBalance").textContent=money(cashBalance());document.getElementById("cashBalance2").textContent=money(cashBalance());document.getElementById("totalCapital").textContent=money(state.capital);document.getElementById("lentCapital").textContent=money(state.credits.reduce((s,c)=>s+c.amount,0));document.getElementById("outstanding").textContent=money(totalOutstanding());document.getElementById("collected").textContent=money(totalCollected());document.getElementById("activeClients").textContent=state.clients.filter(c=>c.status==="active").length;document.getElementById("arrears").textContent=ar.length;document.getElementById("activeCredits").textContent=cc.length;let td=state.payments.filter(p=>p.date===today());document.getElementById("todayCollected").textContent=money(td.reduce((s,p)=>s+p.amount,0));document.getElementById("todayCommission").textContent=money(td.reduce((s,p)=>s+p.commission,0))}
function renderClients(){let q=document.getElementById("clientSearch").value?.toLowerCase()||"";let list=state.clients.filter(c=>(c.name+" "+c.phone).toLowerCase().includes(q));document.getElementById("clientsList").innerHTML=list.map(c=>{let cs=state.credits.filter(x=>x.clientId===c.id), bal=cs.reduce((s,x)=>s+x.outstanding,0);return `<div class="card"><h3>${c.name}</h3><div class="muted">${c.phone||"Sin teléfono"} · ${c.address||"Sin zona"}</div><p>${c.business||""}</p><span class="tag">${cs.length} crédito(s)</span> <span class="tag ${bal?"":"green"}">Saldo ${money(bal)}</span><div class="actions"><button class="small-btn" onclick="newCreditFor('${c.id}')">Nuevo crédito</button></div></div>`}).join("")||`<div class="panel">No hay clientes todavía.</div>`}
window.newCreditFor=id=>{openCreditModal();setTimeout(()=>{let s=document.querySelector('#creditForm select[name="clientId"]');if(s)s.value=id},0)}
function renderCredits(){let f=document.getElementById("creditFilter").value, list=state.credits.filter(c=>f==="all"||(f==="active"&&creditStatus(c)==="active")||(f==="overdue"&&creditStatus(c)==="overdue")||(f==="finished"&&creditStatus(c)==="finished"));document.getElementById("creditsList").innerHTML=list.map(c=>{let st=creditStatus(c), cl=client(c.clientId);return `<div class="card"><h3>${cl?.name||"Cliente eliminado"}</h3><div class="muted">${c.id} · vence ${c.dueDate}</div><p>Prestado <b>${money(c.amount)}</b> · Total <b>${money(c.total)}</b></p><div class="amount">Pendiente ${money(c.outstanding)}</div><p>Cuota diaria: ${money(c.daily)}</p><span class="tag ${st==="overdue"?"red":st==="finished"?"green":""}">${st==="overdue"?`Mora: ${daysLate(c.dueDate)} días`:st==="finished"?"Terminado":"Activo"}</span><div class="actions"><button class="small-btn" onclick="payCredit('${c.id}')">Registrar pago</button></div></div>`}).join("")||`<div class="panel">No hay créditos.</div>`}
window.payCredit=id=>{openPaymentModal();setTimeout(()=>{let s=document.querySelector('#paymentForm select[name="creditId"]');if(s)s.value=id},0)}
function renderPayments(){let p=[...state.payments].reverse();document.getElementById("paymentsList").innerHTML=p.map(x=>`<div class="card"><h3>${client(x.clientId)?.name||"Cliente"}</h3><div class="muted">${x.date} · ${x.method}</div><p class="amount">${money(x.amount)}</p><span class="tag">Comisión ${money(x.commission)}</span><span class="tag green">Neto ${money(x.net)}</span></div>`).join("")||`<div class="panel">Todavía no hay pagos registrados.</div>`}
function renderCash(){let p=[...state.cash].reverse();document.getElementById("cashList").innerHTML=p.map(x=>`<div class="card"><h3>${x.concept}</h3><div class="muted">${x.date} · ${x.type}</div><p>Entrada: <b>${money(x.entry)}</b> · Salida: <b>${money(x.exit)}</b></p></div>`).join("")||`<div class="panel">No hay movimientos.</div>`}
function renderReports(){let principal=state.credits.reduce((s,c)=>s+c.amount,0), interest=state.credits.reduce((s,c)=>s+c.interestAmount,0), comm=state.payments.reduce((s,p)=>s+p.commission,0), exp=state.cash.filter(x=>x.type==="expense").reduce((s,x)=>s+x.exit,0), rec=principal?Math.min(100,totalCollected()/state.credits.reduce((s,c)=>s+c.total,0)*100):0;document.getElementById("interestGenerated").textContent=money(interest);document.getElementById("commissionTotal").textContent=money(comm);document.getElementById("expensesTotal").textContent=money(exp);document.getElementById("recoveryRate").textContent=(isFinite(rec)?rec:0).toFixed(1)+"%";document.getElementById("reportRows").innerHTML=`<div class="row"><span>Capital colocado histórico</span><b>${money(principal)}</b></div><div class="row"><span>Saldo pendiente actual</span><b>${money(totalOutstanding())}</b></div><div class="row"><span>Pagos registrados</span><b>${state.payments.length}</b></div>`}
render();
if("serviceWorker" in navigator) navigator.serviceWorker.register("service-worker.js").catch(()=>{});
