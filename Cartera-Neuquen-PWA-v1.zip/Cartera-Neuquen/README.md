# Cartera Neuquén — PWA v1
Prototipo funcional móvil para gestionar clientes, créditos, pagos, caja, mora, reportes y configuración.

## Parámetros iniciales
- Capital: ARS 10.000.000
- Interés: 20%
- Plazo: 22 días
- Comisión cobrador: 4%
- Datos locales en el dispositivo mediante localStorage.

## Importante
Esta primera versión es un prototipo operativo local. Antes de usarla con dinero o datos reales debe añadirse autenticación, base de datos remota, copias de seguridad, control de permisos y revisión legal/contable.
